#-*- coding:utf-8 -*-

#python3.5
#打印字符串以及数学表达式
print('provinm')
print(1+2-3*5/7)
#两次print，但只显示一行
print('this is first line,',end='')
print('this is also first line')
#一次print显示两行
print('here occupies a line ,\nhere occupies another line')

#python2.7
# print 'provinm'
# print 1+2-3*5/7
#
# print 'this is first line,',
# print 'this is also first line'

# print 'here occupies a line ,\nhere occupies another line'