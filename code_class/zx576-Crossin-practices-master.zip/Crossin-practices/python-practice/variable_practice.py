#-*- coding:utf-8 -*-
a = 'hello,world'
b = 1.414
c = 1 != 2
d = 1 and 2
e = 1 or 2

#python3.5
#'第一题：普通打印'
print(a,b,c,d,e)

#'第二题：格式化输出'
print('a:%s,b:%.2f,c:%s,d:%d,e:%d' %(a,b,c,d,e))

#'第三题：转义符的使用'
print('\'hello,world\'','\n','\\\'hello,world\'')

#python2.7
#'第一题：普通打印'
# print a,b,c,d,e
#
#'第二题：格式化输出'
# print 'a:%s,b:%.2f,c:%s,d:%d,e:%d' %(a,b,c,d,e)
#
#'第三题：转义符的使用'
# print '\'hello,world\'','\n','\\\'hello,world\''
