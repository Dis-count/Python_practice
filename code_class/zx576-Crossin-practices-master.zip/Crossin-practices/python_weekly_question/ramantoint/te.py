import os

for a, b, c in os.walk(r'D:\github\clone'):
    print(a)
