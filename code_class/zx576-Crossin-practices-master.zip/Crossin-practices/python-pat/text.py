H = [15, 15, 14, 24, 14, 3, 20, 23]
# def func(x+y):
#     return x+y
# a = map(func,H)
# print(a)
# print(sum(H))
sum = 0
for i in H:
    sum += i

print(sum)
