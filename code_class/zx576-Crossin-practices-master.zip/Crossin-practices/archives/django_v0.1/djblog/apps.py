from django.apps import AppConfig


class DjblogConfig(AppConfig):
    name = 'djblog'
