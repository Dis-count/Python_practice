
import random

a = random.uniform(1,3)
print(a)
b = random.triangular(.5)
print(b)
