from turtle import *

bgcolor('black')

home()

pencolor('white')
circle(100,180)

# home()

right(210+170)
circle(120,-120)


