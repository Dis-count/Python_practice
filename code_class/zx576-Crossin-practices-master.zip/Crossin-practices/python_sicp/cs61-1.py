a = {x for x in range(10) if x > 5}
print(a)
print('drow'[::-1])
