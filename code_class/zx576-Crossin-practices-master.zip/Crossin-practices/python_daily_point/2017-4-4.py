import os


# os.system('2+2')
print 'sss'
