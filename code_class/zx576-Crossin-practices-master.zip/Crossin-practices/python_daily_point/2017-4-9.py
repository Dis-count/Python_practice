
list1 = []

def add_list():
    for i in range(10):
        list1.append(i)


        
