# def prisoner_delimma(N, strategy1, strategy2):
#     """
#     >>> prisoner_delimma(4, nice, nice)
#     (4, 4)
#     >>> prisoner_delimma(5, rat, rat)
#     (10, 10)
#     >>> prisoner_delimma(6, nice, rat)
#     (18, 0)
#     >>> prisoner_delimma(2, rat, nice)
#     (0, 6)
#     >>> prisoner_delimma(7, rat, tit_for_tat)
#     (12, 15)
#     >>> prisoner_delimma(7, tit_for_tat, tit_for_tat)
#     (7, 7)
#     """
#
# def nice():
#
#
# def rat():
#
#
# def tit_for_tat():
#

#

def func(list1=[1,2,3]):
    list1.pop()
    return list1