

path = 'xxxx'
path2 = ' '
path3 = 'xxx ''

res = path.strip()
if not res:
    print(res)
