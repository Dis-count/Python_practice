s = 'hello'

iter_s = iter(s)

for ele in iter_s:
    print(ele)

print(type(iter_s))
