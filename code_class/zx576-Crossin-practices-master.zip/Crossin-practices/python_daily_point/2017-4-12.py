# from 2017-4-9 import add_list,list1
from example import add_list,list1


add_list()

print(list1)
