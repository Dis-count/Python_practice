a = {}

a['武汉'] = 1
a['ele'] = 2

b = input('>>>')
c = input('>>>')

if b in a:
    print(b)

else:
    print('not found')
